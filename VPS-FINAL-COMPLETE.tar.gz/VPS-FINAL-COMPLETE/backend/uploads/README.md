# Uploads Directory

This directory stores uploaded product images and files.

**Do not delete this folder.**

It will be automatically created if missing when the server starts.
